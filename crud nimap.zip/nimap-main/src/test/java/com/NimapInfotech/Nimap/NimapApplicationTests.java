package com.NimapInfotech.Nimap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NimapApplicationTests {

	@Test
	void contextLoads() {
	}

}
